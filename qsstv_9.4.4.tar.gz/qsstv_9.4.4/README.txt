For the full manual please go to
http://users.telenet.be/on4qz/qsstv/manual/index.html

There you'll find the complete installation instructions wich is part of the user manual.



