#ifndef CONFIGPARAMS_H
#define CONFIGPARAMS_H

#include "cwconfig.h"
#include "directoriesconfig.h"
#include "drmprofileconfig.h"
#include "ftpconfig.h"
#include "guiconfig.h"
#include "hybridconfig.h"
#include "operatorconfig.h"
#include "repeaterconfig.h"
#include "rigconfig.h"
#include "soundconfig.h"
#include "waterfallconfig.h"
#include "frequencyselectwidget.h"

#endif // CONFIGPARAMS_H
