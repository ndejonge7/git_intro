#ifndef HEXCONVERTOR_H
#define HEXCONVERTOR_H

#include <QString>
#include <QByteArray>



bool hexFromString(QString s, QByteArray &ba, bool toHex);
#endif // HEXCONVERTOR_H
